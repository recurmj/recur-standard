# Recur Reference – RIP‑001
Minimal reference implementation of permissioned‑pull (consented continuity) for ERC‑20 balances.

## Quickstart
See `contracts/RecurPull.sol` and `sdk/` helpers.
