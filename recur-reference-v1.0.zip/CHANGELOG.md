## v1.0.0 – initial public reference
