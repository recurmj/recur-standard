# Sample Flows
- Recurring top-up
- Pay-per-use
- Instant revoke
