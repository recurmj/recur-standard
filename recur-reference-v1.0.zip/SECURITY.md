Report issues privately: security@recurlabs.com
